These tools can be used to update Bluetooth Hats running outdated firmware on Windows 10.

Instructions

- Power on the Hat to be updated
- Ensure no other Hats are powered on nearby 
- Double click to run "1. setHatToUpdateMode.exe"
- A brief command prompt should open, once it closes you should notice the LED on the Hat should be solid green
- If the LED is not solid green, please try again. If the problem persists, contact customer support.
- Double click to run "2. Recover.exe"
- A command prompt should open, establish a connection the the Hat and begin the update process.
- You should see progress updates